#include <iostream>
#include "Dvector.h"

using namespace std;

int main()
{
    //Dvector vect(3,2);
    //vect.display(cout);
    Dvector(3, 2).display(cout);
    return 0;
}
